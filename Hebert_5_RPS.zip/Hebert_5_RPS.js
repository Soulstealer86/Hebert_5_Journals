var cCoi = Math.random();
 var uCoi = "U";
  var w = "Win";
   var l = "Lose";
    var d = document;
     var dmS = d.getElementById("myStatu");
	  var dsC = d.getElementById("Score");
       var dsT = d.getElementById("Statu");

function rp() {window.location.href=window.location;}

function r() {window.uCoi = "R"; dmS.innerHTML =("User: "+uCoi);}
 function p() {window.uCoi = "P"; dmS.innerHTML =("User: "+uCoi);}
  function s() {window.uCoi = "S"; dmS.innerHTML =("User: "+uCoi);}

if (cCoi < 0.32) {var cCoi = "R";} else if (cCoi < 0.62) {var cCoi = "P";} else {var cCoi = "S";}
	var print = "Computer:  "+cCoi+"<br>";


function g(){
	if (uCoi === cCoi) {
		dsT.innerHTML =(print);
		dsC.innerHTML =("Tie");
		dsC.style.background = "#d8c43e";
		dsC.style.border = "1px solid #d8c43e";
	} else if (uCoi == "R"){
		if (cCoi == "P") {
			dsT.innerHTML =(print);
			dsC.innerHTML =(l);
			dsC.style.background = "#883737";
			dsC.style.border = "1px solid #ed4040";
		} else {
			dsT.innerHTML =(print);
			dsC.innerHTML =(w);
		}
	}else if (uCoi == "P") {
		if (cCoi == "R") {
			dsT.innerHTML =(print);
			dsC.innerHTML =(w);
		} else {
			dsT.innerHTML =(print);
			dsC.innerHTML =(l);
			dsC.style.background = "#883737";
			dsC.style.border = "1px solid #ed4040";
		}
	} else {
		if (cCoi == "P") {
			dsT.innerHTML =(print);
			dsC.innerHTML =(w);
		} else {
			dsT.innerHTML =(print);
			dsC.innerHTML =(l);
			dsC.style.background = "#883737";
			dsC.style.border = "1px solid #ed4040";
		}
	}
}
